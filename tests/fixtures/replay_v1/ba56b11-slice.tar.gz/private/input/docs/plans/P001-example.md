---
revision: 2
---
# P001: Example

## Slices

### S1: First

Status: in-progress

Risk: Files may move.

Preserve the ABI.

Test the executable.

### S2: Second

Status: todo

Add a renderer.

## Log

PRIVATE history.
